from flask import render_template, current_app
from app import socketio
from .camera import get_realsense_frame

def init_routes(app):
    @app.route('/')
    def index():
        return render_template('index.html')

    @socketio.on('connect')
    def handle_connect():
        socketio.start_background_task(get_realsense_frame)

# Call this function in __init__.py after creating the app
# init_routes(current_app)