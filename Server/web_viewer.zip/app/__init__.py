from flask import Flask
from flask_socketio import SocketIO

socketio = SocketIO()

def create_app():
    app = Flask(__name__)
    app.config.from_object('config.Config')

    socketio.init_app(app)

    with app.app_context():
        from app import routes
        from .routes import init_routes
        init_routes(app)

    return app